<!DOCTYPE html>

<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="content-type" content="text/html; charset=utf-8">
        <link rel="stylesheet" type="text/css" href="css/template_live.css">
        <title>Home</title>
    </head>
    
    <body>
    
        <h1>La Casa Hotel</h1>
            
        <nav>
            <ul id = "nav">
                <li id="current"><a>Home</a></li>
                <li> <a href="rooms.php">View Rooms</a> </li>
                <li> <a href="book.php">Book a Room</a> </li>

            </ul>
        </nav>
        
        <div id ="main">
        
            <p>
                This is a bare-bones solution to the core requriements of assignment 1.
                It can be used as a basis for assignment 2, but is by no means complete.
                It also (as you can probably tell) does not include any styling, extras, or careful validation of user input.
            </p>
            
        </div>
        
    </body>
</html>