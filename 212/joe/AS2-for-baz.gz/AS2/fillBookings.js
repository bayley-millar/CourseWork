var delBooking = (function () {
    "use strict";
    var pub = {};

    function makeDateFromXML(xmlDate) {
        var dd, mm, yyyy;

        dd = $(xmlDate).find("day").text();
        
        mm = $(xmlDate).find("month").text();
       
        yyyy = $(xmlDate).find("year").text();

        return dd + '-' + mm + '-' + yyyy;
    }

    /**
     * Display current bookings.
     *
     * Current bookings are read from an XML file and displayed as a list in a select tag as an option.
     */
    function readBookings() {
        var target2 = $("#bookingList");
        
        $.ajax({
            type: "GET",
            url: "roomXML/roomBookings.xml",
            cache: false,
            success: function (data) {
                $(data).find("booking").each(function () {
                    var name, number, checkin, checkout;
                    number = $($(this).find("number")[0]).text();
                    name = $($(this).find("name")[0]).text();
                    checkin = makeDateFromXML($($(this).find("checkin")[0]));
                    checkout = makeDateFromXML($($(this).find("checkout")[0]));
                    //$("#bookingList").append($("<li>").text(name + " - Room " + number + " from " + checkin + " to " + checkout));
                    target2.append($("<option>").text(name + " - Room " + number + " from " + checkin + " to " + checkout));
                    target2.append("</option>");
                });
            }
        });
    }

   
    /**
     * Setup function for administration page.
     *
     * This function displays a list of existing bookings.
     */
    pub.setup = function () {
        readBookings();

        
    };

    // Expose public interface
    return pub;
}());

$(document).ready(delBooking.setup);