<?php
    
    /*This PHP file deleted the selected room from the XML file, it also deletes any booking that matches the room number. */

    session_start();
    $roomNum = $_POST['rooms'];

?>

<?php
        $xml = simplexml_load_file('../roomXML/hotelRooms.xml');

        $rooms = $xml->xpath('hotelRoom');
        
foreach($rooms as $room){
    $roomNumber = $room->number;
    if($roomNumber == $roomNum){
        unset($room[0]);
    }
}
 
        $xml->saveXML('../roomXML/hotelRooms.xml');

$xml2 = simplexml_load_file('../roomXML/roomBookings.xml');
$bookings = $xml2->xpath('booking');

foreach($bookings as $booking){
    $number = $booking->number;
    if($number == $roomNum){
        unset($booking[0]);   
    }
}
$xml2->saveXML('../roomXML/roomBookings.xml');


        $page = $_SESSION['lastpage'];
        header("Location: $page");
        /*$_SESSION = array();
        session_destroy();*/
     ?>