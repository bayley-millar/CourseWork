

<?php

/* This PHP file gets booking infomation out of the cookie, then inserts in into XML.
   Once this has happened successfully the cookie is then deleted.*/

$bookings_xmlFile = simplexml_load_file('../roomXML/roomBookings.xml');

if (isset($_COOKIE['cart'])){
    $bookings_in_cookie = json_decode($_COOKIE['cart']);
    
    foreach($bookings_in_cookie as $booking){
        $newBooking = $bookings_xmlFile->addCHild('booking');
        $newBooking->addChild('number', $booking->roomNum);
        $newBooking->addChild('name', $booking->guestName);
        
        list($dayIn, $monthIn, $yearIn) = explode('/', $booking->checkIn);
        
        $checkIn = $newBooking->addChild('checkin');
        $checkIn->addChild('day', $dayIn);
        $checkIn->addChild('month', $monthIn);
        $checkIn->addChild('year', $yearIn);
        
        list($dayOut, $monthOut, $yearOut) = explode('/', $booking->checkOut);
        
        $checkOut = $newBooking->addChild('checkout');
        $checkOut->addChild('day', $dayOut);
        $checkOut->addChild('month', $monthOut);
        $checkOut->addChild('year', $yearOut);
        
    }
    
    setcookie('cart', '', time()-3600, '/');
    unset($_COOKIE['cart']);
    file_put_contents('../roomXML/roomBookings.xml', $bookings_xmlFile->asXML());
}


?>
