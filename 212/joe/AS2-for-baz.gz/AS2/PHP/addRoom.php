<?php
    
    /*This PHP file adds a new room to the appropriate XML file with all the required infomation */

    session_start();
    $_SESSION['roomNumber'] = $_POST['roomNumber'];
    $_SESSION['roomType'] = $_POST['roomType'];
    $_SESSION['description'] = $_POST['description'];
    $_SESSION['pricePerNight'] = $_POST['pricePerNight'];
    $errors = 0;
?>

 <?php if ($errors === 0) {
        $xml = simplexml_load_file('../roomXML/hotelRooms.xml');
        
        //Room hotelRooms XML
        
        $hotelRoom = $xml->addChild('hotelRoom'); 
        $hotelRoom->addChild('number', $_POST['roomNumber']);
        $hotelRoom->addChild('roomType', $_POST['roomType']);
        $hotelRoom->addChild('description', $_POST['description']);
        $hotelRoom->addChild('pricePerNight', $_POST['pricePerNight']);
 
        $xml->saveXML('../roomXML/hotelRooms.xml');
        $page = $_SESSION['lastpage'];
        header("Location: $page");
        
    } ?>

