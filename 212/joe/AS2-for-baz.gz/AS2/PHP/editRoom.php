<?php

/* This PHP file used infomation on the edit rooms form to update a given room's infomation and makes those
   changes in the appropriate XML file.*/
    
    session_start();
    include("validationFunctions.php");

        
    $selectedRoom = $_POST['roomToEdit'];
    $newRoomType = $_POST['editRoomType'];
    $newRoomDesc = $_POST['editDescription'];
    $newPpn = $_POST['editPricePerNight'];


    
    
?>

<?php

    $xml = simplexml_load_file('../roomXML/hotelRooms.xml');

        $rooms = $xml->xpath('hotelRoom');
        
// foreach loop to insert updated info into xml    
foreach($rooms as $room){
    $roomNumber = $room->number;
    if($selectedRoom == $roomNumber){
        unset($room[0]);
        $hotelRoom = $xml->addChild('hotelRoom');
        $hotelRoom->addChild('number', $_POST['roomToEdit']);
        $hotelRoom->addChild('roomType', $_POST['editRoomType']);
        $hotelRoom->addChild('description', $_POST['editDescription']);
        $hotelRoom->addChild('pricePerNight', $_POST['editPricePerNight']);
        
           
    }
}

        $xml->saveXML('../roomXML/hotelRooms.xml');
        $page = $_SESSION['lastpage'];
        header("Location: $page");
        
    
    



?>