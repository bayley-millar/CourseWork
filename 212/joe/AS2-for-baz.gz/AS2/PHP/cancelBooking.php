<?php
    /*This PHP file is for cancelling any selected bookings, thus removing them from XML. */
    
    session_start();
    $bookingsList = $_POST['bookingList'];

?>

<?php
        $xml = simplexml_load_file('../roomXML/roomBookings.xml');

        $bookings = $xml->xpath('booking');
        
foreach ($bookings as $booking) {
            $name = $booking->name;  
            $number = $booking->number;
            $inday = $booking->checkin->day;
            $inmonth = $booking->checkin->month;
            $inyear = $booking->checkin->year;
            $checkin = $inday . '-' . $inmonth . '-' . $inyear;
            $outday = $booking->checkout->day;
            $outmonth = $booking->checkout->month;
            $outyear = $booking->checkout->year;
            $checkout = $outday . '-' . $outmonth . '-' . $outyear;
            $bookingStr = $name . ' - Room ' . $number . ' from ' . $checkin . ' to ' . $checkout;
            if ($bookingStr == $bookingsList) {
                unset($booking[0]);
                
            } 
            
}
        

 
        $xml->saveXML('../roomXML/roomBookings.xml');
        $page = $_SESSION['lastpage'];
        header("Location: $page");
        


?>