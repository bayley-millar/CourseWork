<?php
    session_start();
    $_SESSION['lastpage'] = $_SERVER['PHP_SELF'];
    include("PHP/validationFunctions.php");
?>



<!DOCTYPE HTML>
<html lang='en'>

<head>
    <title>Rise Resort | Hotel</title>
    <link rel="stylesheet" href="stylesheet.css">
    <script src="jquery-1.11.3.min.js"></script>
    <script src="viewBookings.js"></script>
    <script src="bookingValidation.js"></script>
    <script src="bookDates.js"></script>
    <script src="fillBookings.js"></script>
    
    <meta charset="utf-8">
</head>

<body>
    <div id="page">
        <div id="header">
            <h1>RISE RESORT</h1>
            <p>"The best hotel in the word"</p>
            <div id="nav">
                <ul>
                    <li>Staff Administration</li>
                </ul>
            </div>
        </div>

        <div id="mainContent">
            <h2>Current Bookings</h2>
            <form id="adminSearch">
                <fieldset class="formBorders">
                    <legend>Search Bookings</legend>
                    <label class="admin">Room Number:</label>
                    <input type="text" name="number" id="roomNO" placeholder='Room Number'>
                    <br>
                    <label>Guest Name:</label>
                    <input type="text" name="guest" id="guestName" placeholder='Guest Name'>
                    <input type="button" value="Reset" id="resetSearch">
                </fieldset>
            </form>
            <div id="confirmedBookings">
                <ul id="bookings"></ul>
            </div>
            <h2>Administrative Tools</h2>
            <div>
                <form id="addRooms" action="PHP/addRoom.php" method="POST">
                        <fieldset class="formBorders">
                    <legend><span>Add a room</span></legend>
                <p>
                    <label for="roomNumber">Room number: </label>
                    <input type="text" name="roomNumber" id="roomNumber" placeholder='Room Number' required>
                </p>
                <p>
                    <label for="roomType">Room Type: </label>
                    <select id="roomType" name="roomType" required>
                        <option value="Single">Single</option>
                        <option value="Double">Double</option>
                        <option value="Twin">Twin</option>
                        <option value="King">King</option>
                        <option value="Triple Room">Triple Room</option>
                        
                    </select>
                </p>
                    <p>
                    <label for="description">Description: </label>
                    <input type="text" name="description" id="description" placeholder='Room Description' required>
                </p>
                    <p>
                    <label for="pricePerNight">Price per Night: </label>
                    <input type="text" name="pricePerNight" id="pricePerNight" placeholder='0.00' required>
                </p>
                            <p>
                    <input type="submit" name="addRoom" id="addRoom" value = "Add room">
                </p>
                </fieldset>
                </form>
                
            </div>
            
            <div>
                <form id="deleteRoom" action="PHP/deleteRoom.php" method="post">
                    <fieldset class="formBorders">
                    <legend><span>Delete a room</span></legend>
                        <p>Warning: Deleting a room with a booking/s already confirmed shall also be deleted.</p>
                    <p>
                    <label for="rooms">Room Type: </label>
                        <select id="rooms" name="rooms" required>
                        </select>
                        
                </p>
                        <p>
                    <input type="submit" name="deleteRoom" id="deleteRoomSubmit" value = "Delete room">
                </p>
                    </fieldset>
                
                </form>
            
            </div>
            
             <div>
                <form id="cancelBookingForm" action="PHP/cancelBooking.php" method="post">
                    <fieldset class="formBorders">
                    <legend><span>Cancel any booking</span></legend>
                    <p>
                    <label for="bookings">Bookings: </label>
                        <select id="bookingList" name="bookingList"></select>
                </p>
                        <p>
                    <input type="submit" name="cancelBooking" id="cancelBooking" value = "Cancel Booking">
                </p>
                    </fieldset>
                
                </form>
            
            </div>
            
            <div>
                <form id="editRoomForm" action="PHP/editRoom.php" method="post">
                    <fieldset class="formBorders">
                    <legend><span>Edit Room:</span></legend>
                    <p>
                    <label for="roomToEdit">Room to edit: </label>
                        <select id="roomToEdit" name="roomToEdit"></select>
                </p>
                       <p>
                    <label for="editRoomType">New Room Type: </label>
                    <select id="editRoomType" name="editRoomType">
                        <option value="Single">Single</option>
                        <option value="Double">Double</option>
                        <option value="Twin">Twin</option>
                        <option value="King">King</option>
                        <option value="Triple">Triple Room</option>
                        
                    </select>
                </p>
                        <p>
                    <label for="editDescription">New Description: </label>
                    <input type="text" name="editDescription" id="editDescription" placeholder='New Room Description'required>
                            
                </p>
                        
                        
                        <p>
                    <label for="editPricePerNight">New Price per Night: </label>
                    <input type="text" name="editPricePerNight" id="editPricePerNight" placeholder='New PPN 0.00'required>
                        
                </p>
                        <p>
                    <input type="submit" name="editRoom" id="editRoom" value = "Update Room">
                </p>
                        
                            
                    </fieldset>
                
                </form>
            
            </div>


        </div>
        <div id="footer">

            Designed by Joe Benn &copy; 2015 Rise Resort

        </div>

    </div>
</body>

</html>
