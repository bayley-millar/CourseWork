var Booking = (function () {
    "use strict";
    var pub = {};

    /*Method generated the select drop down menu of avaliable rooms given the dates*/
    function parseRooms(data, bookedRooms) {
        var selectOptions = document.getElementById("chooseRoom");
        var selectOptions2 = document.getElementById("rooms");
        var selectOptions3 = document.getElementById("roomToEdit");
        var str = '';
        var str2 = '';
        $(data).find("hotelRoom").each(function () {
            var number = $(this).find("number")[0].textContent;
            if ($.inArray(number, bookedRooms) === -1) {
                var ppn = $(this).find("pricePerNight")[0].textContent;
                var bedding = $(this).find("roomType")[0].textContent;
                str += ("<option value=" + number + ">" + number + ": " + bedding + " - " + "$" + ppn + "</option>\n");
                str2 += ("<option value=" + number + ">" + number + "</option>\n");
            }
        });
        if(!(selectOptions === null)){
        selectOptions.innerHTML = str;
        } else {
            
        selectOptions2.innerHTML = str2;
        selectOptions3.innerHTML = str2;
        }
    }


    pub.setup = function (bookedRooms) {
        $.ajax({
            type: "GET",
            url: "roomXML/hotelRooms.xml",
            cache: false,
            success: function (data) {
                parseRooms(data, bookedRooms);
            }

        });
    };
    return pub;
}());

$(document).ready(Booking.setup);
